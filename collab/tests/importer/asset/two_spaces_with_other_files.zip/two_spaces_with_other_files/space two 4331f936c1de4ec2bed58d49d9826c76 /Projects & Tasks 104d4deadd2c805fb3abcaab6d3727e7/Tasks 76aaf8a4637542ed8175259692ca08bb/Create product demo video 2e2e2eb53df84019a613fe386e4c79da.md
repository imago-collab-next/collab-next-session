# Create product demo video

Assignee: Nate Martins
Status: Done
Due: April 29, 2024
Project: Product launch (../Projects%2058b8977d6e4444a98ec4d64176a071e5/Product%20launch%206d28c38ede8641c1bbd241cea82810c9.md)
Priority: High
Tags: Video production
Completed on: May 1, 2024
Delay: 2